import numpy as np
import math

def calculate_rms(audio):
  audio_array = np.array(audio.get_array_of_samples())
  rms = math.sqrt(np.mean(audio_array ** 2))
  return rms

def calculate_noise_rms(audio, target_snr):
  signal_rms = calculate_rms(audio)
  noise_rms = signal_rms / (10 ** (target_snr / 20.0))
  return noise_rms

def audioSNR(audio_a, audio_b):
  max_len = max(len(audio_a), len(audio_b))
  audio_a = audio_a[:max_len].set_frame_rate(audio_a.frame_rate)
  audio_b = audio_b[:max_len].set_frame_rate(audio_b.frame_rate)
  a = np.array(audio_a.get_array_of_samples())
  b = np.array(audio_b.get_array_of_samples())
  signal_energy = np.sum(a.astype(np.float64) ** 2)
  noise = a - b
  noise_energy = np.sum(noise.astype(np.float64) ** 2)
  print(signal_energy,noise_energy)
  if noise_energy == 0:
    snr = -100
  else:
    snr = 10 * np.log10(signal_energy / noise_energy)
  print(snr)

