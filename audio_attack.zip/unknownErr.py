from pydub import AudioSegment

def speed_control(audio,rate):
  if len(audio) == 0:
    return None
  else:
    result = audio.speedup(playback_speed=rate)
    return result

def speed_control(audio,interval,rate):
  result = AudioSegment.empty()
  for i in range(0, len(audio), interval * 20):
    segment = audio[i:i + interval*10 ]
    segment.export("output\\tmp_audio.wav", format="wav")
    result += segment.speedup(rate)
    segment = audio[i + interval*10 :i + interval * 20]
    segment.export("output\\tmp1_audio.wav", format="wav")
    result += segment.speedup(1/rate)
  return result
#使用audio.speedup函数的这两个抽象的函数在传入rate小于1会报错，只能加速不能减速
