import matplotlib.pyplot as plt
import numpy as np
import os

def printAudio(audio):
  samples = np.array(audio.get_array_of_samples())
  fig, axes = plt.subplots(2, 1, figsize=(12, 8))
  axes[0].plot(samples, color='b')
  axes[0].set_title('Wave')
  axes[0].set_xlabel('Sample')
  axes[0].set_ylabel('Amplitude')

  axes[1].specgram(samples, Fs=audio.frame_rate)
  axes[1].set_title('Spectrogram')
  axes[1].set_xlabel('Time')
  axes[1].set_ylabel('Frequency')
  plt.tight_layout()
  plt.show()



def audio_save(file_path,audio):
  file_name = os.path.basename(file_path)
  output_folder = "output"
  new_file_path = os.path.join(output_folder, file_name)
  audio.export(new_file_path, format="wav")
  print(f"处理后音频 {file_name} 已保存至 {output_folder}.")
