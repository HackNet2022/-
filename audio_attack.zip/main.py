from watermark import *
from pretreatment import *
from frequency import *
from wavaform import *
from unknownErr import *
from output import *
from recognizer import *

def process(file_path):
  audio_a, audio_b, audio_c = audioInput(file_path)
  oriAudio = audio_b
  audio_c = audioLower(audio_c,-15)
  combined_audio = audio_b

  #combined_audio = insert_silence(combined_audio)
  #combined_audio = average(combined_audio)

  # combined_audio = audioInsert(combined_audio, audio_a)

  combined_audio = add_watermark(combined_audio)
  #combined_audio = add_noise_to_wav_files(combined_audio, audio_c)
  combined_audio = audio_overlay(combined_audio,audio_c)
  # combined_audio = waveChange(combined_audio)
  # combined_audio = add_salt_and_pepper_noise(combined_audio)
  #combined_audio = add_gaussian_noise(combined_audio)
  # combined_audio = add_gabor_noise(combined_audio)
  #printAudio(combined_audio)

  #combined_audio = fft_random(combined_audio, 0.00001)
  combined_audio = fft_mix(combined_audio,audio_c)
  combined_audio = ultrasonic(combined_audio)#最后叠超声波
  audio_save(file_path,combined_audio)


if __name__ == '__main__':
  wav_filepath=transformer()
  divider(wav_filepath)
  # folder_path = "input2"
  # for file in os.listdir(folder_path):
  #   if file.endswith(".wav"):
  #     file_path = os.path.join(folder_path, file)
  #     process(file_path)


  # printAudio(audio_a)
  #printAudio(oriAudio)
  #printAudio(combined_audio)
  #audioSNR(combined_audio,oriAudio)

  # sound = AudioSegment.from_wav("jojo.wav")
  # sound.export("jojo.mp3", format="mp3")
