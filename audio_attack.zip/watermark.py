
import io
from pydub import AudioSegment
from PIL import Image

def add_watermark(audio):
  img = Image.open('material//watermark.bmp')
  buffered = io.BytesIO()
  img.save(buffered, format="BMP")
  bmp_data = buffered.getvalue()

  watermark_audio = AudioSegment.silent(duration=1000)
  result = audio.overlay(watermark_audio, position=0)
  #result.export("marked_audio.mp3", format="mp3")
  return result



def transformer():
  with open("material\\watermark.txt", "r") as file:
    text = file.read()

  width = len(text.splitlines()[0])
  height = len(text.splitlines())
  img = Image.new('1', (width, height), 1)
  pixels = img.load()

  for y in range(height):
    line = text.splitlines()[y]
    for x in range(width):
      if line[x] == '1':
        pixels[x, y] = 0
  img.save("watermark.bmp")
