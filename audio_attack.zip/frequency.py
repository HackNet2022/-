import numpy as np
import math
from pydub import AudioSegment
from recognizer import *

def add_noise_to_wav_files(audio_path, noise):
  a = 50 #a与强度成反比
  audio = audio_path
  noise_rms = calculate_noise_rms(audio, a)
  adjusted_noise = noise - (calculate_rms(noise) - noise_rms)
  repeated_noise = adjusted_noise * (len(audio) // len(adjusted_noise) + 1)
  repeated_noise = repeated_noise[:len(audio)]


  noisy_audio = audio.overlay(repeated_noise)
  return noisy_audio

def fft_random(audio,strength):
  audio_array = np.array(audio.get_array_of_samples())
  audio_fft = np.fft.fft(audio_array)
  noise = np.random.normal(0, strength, len(audio_array))
  audio_noise = audio_fft + noise
  audio_noise =  audio_noise.real
  array = np.fft.ifft(audio_noise)
  result = audio._spawn(array.astype(np.int16))
  #printAudio(result)
  return result

def fft_mix(audio,noise):
  audio_array = np.array(audio.get_array_of_samples())
  noise_array = np.array(noise.get_array_of_samples())

  if len(audio_array) < len(noise_array):
    noise_array = noise_array[:len(audio_array)]
  elif len(audio_array) > len(noise_array):
    noise_array = np.pad(noise_array,len(audio_array)-len(noise_array))

  audio_fft = np.fft.fft(audio_array)
  noise_fft = np.fft.fft(noise_array)

  combined_audio = audio_fft + noise_fft
  result = np.fft.ifft(combined_audio)
  result = AudioSegment(
    data=result.astype(np.int16).tobytes(),
    sample_width=audio.sample_width,
    frame_rate=audio.frame_rate,
    channels=audio.channels
  )
  return  result

