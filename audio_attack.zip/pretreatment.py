import os
from pydub import AudioSegment

def transformer():
  source_folder = "input"
  target_folder = "input1"
  if not os.path.exists(target_folder):
    os.makedirs(target_folder)
  for filename in os.listdir(source_folder):
    if filename.endswith(".mp3"):
      file_path = os.path.join(source_folder, filename)
      audio = AudioSegment.from_mp3(file_path)
      wav_filename = os.path.splitext(filename)[0] + ".wav"
      wav_filepath = os.path.join(target_folder, wav_filename)
      audio.export(wav_filepath, format="wav")
  return wav_filepath

def divider(file_path):
  audio = AudioSegment.from_wav(file_path)
  file_name = os.path.basename(file_path)
  interval = 30 * 1000
  for i, chunk in enumerate(audio[::interval]):
    file_path = os.path.join("input2", file_name+f"{i + 1}.wav")
    chunk.export(file_path, format="wav")

def average(audio):
  a=100
  frames = audio.get_array_of_samples()
  new_frames = []

  for i in range(0, len(frames), a):
    prev_frame = frames[i - 1] if i > 0 else frames[i]
    next_frame = frames[i + 1] if i < len(frames) - 1 else frames[i]
    average_frame = (prev_frame + next_frame) // 2

    new_frames.extend([prev_frame, average_frame])

  new_audio = audio._spawn(new_frames)
  result = new_audio.set_channels(audio.channels).set_sample_width(audio.sample_width)
  # printAudio(result)
  return result

def audioLower(audio,lound):
  power = 0.01
  audio = audio.apply_gain(power)
  audio = audio + lound
  return audio



def audioInput(file_path):
  audio_a = AudioSegment.from_file("material\\audio_a.wav")
  audio_b = AudioSegment.from_file(file_path)
  audio_c = AudioSegment.from_file("material\\background.wav")
  audio_a = audio_a.set_channels(audio_b.channels)
  audio_a = audio_a.set_frame_rate(audio_b.frame_rate)
  audio_c = audio_c.set_channels(audio_b.channels)
  audio_c = audio_c.set_frame_rate(audio_b.frame_rate)
  return audio_a,audio_b,audio_c
