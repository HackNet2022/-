import numpy as np
from pydub import AudioSegment

#Gabor噪声,a是强度
def add_gabor_noise(audio):
  audio_data = np.array(audio.get_array_of_samples())
  sample_rate = audio.frame_rate
  frequencies = np.linspace(0.1, 10, 20)
  gabor_noise = np.zeros(len(audio_data))

  for f in frequencies:
    a = 500
    t = np.arange(len(audio_data)) / sample_rate
    gabor_waveform = a * np.sin(2 * np.pi * f * t)
    gabor_noise += gabor_waveform

  noisy_audio_data = (audio_data + gabor_noise).astype(np.int16)
  result = AudioSegment(
    data=noisy_audio_data.tobytes(),
    sample_width=audio.sample_width,
    frame_rate=sample_rate,
    channels=audio.channels
  )
  # printAudio(result)
  return result

#高斯噪声
def add_gaussian_noise(audio):
  mean = 0
  std = 0.0001

  samples = np.array(audio.get_array_of_samples())
  noise = np.random.normal(mean, std, len(samples))
  noisy_samples = samples + noise

  noisy_audio = AudioSegment(
      np.int16(noisy_samples).tobytes(),
      frame_rate=audio.frame_rate,
      sample_width=audio.sample_width,
      channels=audio.channels
  )

  result = noisy_audio.normalize()
  # printAudio(result)
  return result

#椒盐噪声
def add_salt_and_pepper_noise(audio):
  a=0.00001
  #audio1 = AudioSegment.from_file(audio)
  samples = np.array(audio.get_array_of_samples())
  noise = np.random.choice([0, 32767], size=len(samples), p=[1 - a, a])
  noisy_samples = np.clip(samples + noise, -32768, 32767).astype(np.int16)

  noisy_audio = AudioSegment(
    data=noisy_samples.tobytes(),
    sample_width=2,
    frame_rate=audio.frame_rate,
    channels=audio.channels
  )
  return noisy_audio


def ultrasonic(audio):
  t = audio.duration_seconds * 1000
  freq = 20000
  samples = (np.sin(2 * np.pi * np.arange(t * freq / 1000) / freq) * 32767).astype(np.int16)
  result = AudioSegment(samples.tobytes(), frame_rate=freq, sample_width=samples.dtype.itemsize, channels=1)
  #printAudio(result)
  audio = audio.overlay(result)
  return audio

def waveChange(audio):
  a=1
  result = audio._spawn(audio.raw_data, overrides={"frame_rate": int(audio.frame_rate * (2.0 ** (a / 12)))})
  speedChange = len(audio) / len(result)
  result = result.speedup(playback_speed=speedChange)
  return result

def audio_overlay(audio,noise):
  length = len(audio)
  noise1 = noise[:length]
  result = audio.overlay(noise1)
  #print(len(result))
  return result

#b插帧到a,每rate帧插1,整数rate最小为1
def audioInsert(audio_a,audio_b):
  rate = 100
  b_start=100
  result = AudioSegment.empty()

  # samples_a = np.array(audio_a.get_array_of_samples())
  # samples_b = np.array(audio_b.get_array_of_samples())
  if(len(audio_a)>len(audio_b)*rate-b_start):
    audio_b = audio_b[:audio_a+b_start].set_frame_rate(audio_b.frame_rate)

  if(rate==1):
    for i in range(len(audio_a)):
      result =result + audio_a[i] + audio_b[b_start+i]

  else:
    j = 1
    print(len(audio_a))
    for i in range(len(audio_a)):
      result += audio_a[i]
      j += 1
      if(j>rate):
        print(i)
        b_start+=1
        result += audio_b[b_start]
        j=1

  # result = AudioSegment(
  # samples=samples_a.astype(np.int16),
  # frame_rate=audio_a.frame_rate,
  # channels=audio_a.channels,
  # sample_width=audio_a.sample_width
  # )
  #result.export("output\inserted_audio.wav", format="wav")
  return result

def insert_silence(audio):
  interval = 100
  channels = audio.split_to_mono()
  new_audio = AudioSegment.empty()

  for channel in channels:
    for i in range(len(channel) // interval):
      start = i * interval
      end = (i + 1) * interval
      frame = channel[start:end]
      new_audio += frame
      new_audio += AudioSegment.silent(duration=frame.duration_seconds)

  return new_audio
